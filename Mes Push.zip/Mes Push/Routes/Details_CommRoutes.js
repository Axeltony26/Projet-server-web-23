import express from "express";

import detailsCommandes from "../controllers/Details_commande.js";

const router = express.Router();

// Récupérer tous les détails des commandes
router.get("/", detailsCommandes.ObtenirLesDetailsCommandes);

// Ajouter un détail de commande
router.post("/", detailsCommandes.ajouterDetailCommande);

// Mettre à jour un détail de commande
router.put("/:id", detailsCommandes.MettreaJourDetailCommande);

// Supprimer un détail de commande
router.delete("/:id", detailsCommandes.SupprimerDetailsCommande);

export default router;
