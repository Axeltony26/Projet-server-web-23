import express from "express";

import { getAllApprovisionnements, getApprovisionnementById,} from "../controllers/Approvisionnement.js";

const router = express.Router();

router.get("/", getAllApprovisionnements);
router.get("/:id", getApprovisionnementById);

export default router;
