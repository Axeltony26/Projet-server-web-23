import {Details_commandes} from "../models/index.js";
 

const detailsCommandes = {};

// Récupérer tous les détails des commandes
detailsCommandes.ObtenirLesDetailsCommandes = async (req, res) => {
  try {
    const detailsCommandes = await Details_commandes.findAll();
    res.json(detailsCommandes);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Une erreur lorsde la récupération des détails des commandes." });
  }
};

// Ajouter un détail de commande
detailsCommandes.ajouterDetailCommande = async (req, res) => {
  try {
    const { nom_produit_achete, quantite, prix } = req.body;
    const newDetailCommande = await Details_commandes.create({ nom_produit_achete, quantite, prix });
    res.json(newDetailCommande);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Une erreur est survenue lors de l'ajout d'un détail de commande." });
  }
};

// Mettre à jour un détail de commande
detailsCommandes.MettreaJourDetailCommande = async (req, res) => {
  try {
    const { id } = req.params;
    const { nom_produit_achete, quantite, prix } = req.body;
    const detailCommandeToUpdate = await Details_commandes.findOne({ where: { id } });
    if (detailCommandeToUpdate) {
      detailCommandeToUpdate.nom_produit_achete = nom_produit_achete;
      detailCommandeToUpdate.quantite = quantite;
      detailCommandeToUpdate.prix = prix;
      await detailCommandeToUpdate.save();
      res.json(detailCommandeToUpdate);
    } else {
      res.status(404).json({ message: "Le détail de commande n'existe pas." });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Une erreur est survenue lors de la mise à jour d'un détail de commande." });
  }
};

// Supprimer un détail de commande
detailsCommandes.SupprimerDetailsCommande = async (req, res) => {
  try {
    const { id } = req.params;
    const detailCommandeToDelete = await Details_commandes.findOne({ where: { id } });
    if (detailCommandeToDelete) {
      await detailCommandeToDelete.destroy();
      res.json({ message: "Le détail de commande a été supprimé avec succès." });
    } else {
      res.status(404).json({ message: "Le détail de commande n'existe pas." });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Une erreur est survenue lors de la suppression d'un détail de commande." });
  }
};

export default detailsCommandes;





