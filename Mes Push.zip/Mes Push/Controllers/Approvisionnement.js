import {Approvisionnement} from "../models/index.js";


export const getAllApprovisionnements = async (req, res) => {
    try {
      const approvisionnements = await Approvisionnement.findAll();
      res.status(200).json(approvisionnements);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  // Obtenir les Approvisonnenent par ID
  export const getApprovisionnementById = async (req, res) => {
    try {
      const approvisionnement = await Approvisionnement.findByPk(req.params.id);
      if (!approvisionnement) {
        res.status(404).json({ message: "Approvisionnement introuvable" });
      } else {
        res.status(200).json(approvisionnement);
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
