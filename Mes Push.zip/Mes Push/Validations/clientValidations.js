import { body } from "express-validator";

const clientRules=[
    body('nom').notEmpty().withMessage('Le nom ne peut pas etre vide'),
    body('prenom').notEmpty().withMessage('Le prenom ne peut pas etre vide'),
    body('email').notEmpty().withMessage('Le champ email ne peut pas etre vide'),
]

export default clientRules