import { body } from "express-validator";

const userRules=[
    body('nom').notEmpty().withMessage('Le nom ne peut pas etre vide'),
    body('prenom').notEmpty().withMessage('Le prenom ne peut pas etre vide'),
]

export default userRules