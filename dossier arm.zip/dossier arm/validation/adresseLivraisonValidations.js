import { body } from "express-validator";

const adresse_livraisonRules=[
    body('nom_destinataire').notEmpty().withMessage('Le nom ne peut pas etre vide'),
    body('prenom_destinataire').notEmpty().withMessage('Le prenom ne peut pas etre vide'),
    body('email').notEmpty().withMessage('Le champ email ne peut pas etre vide'),
]

export default adresse_livraisonRules