import {Fournisseurs} from "../models/index.js";

// récupérer  les fournisseurs
const getAllFournisseurs = async (req, res) => {
  try {
    const fournisseurs = await Fournisseurs.findAll();
    res.status(200).json(fournisseurs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
// ajouter un nouveau fournisseur
const AjoutNouvFournisseur = async (req, res) => {
  try {
    const fournisseur = await Fournisseurs.create(req.body);
    res.status(201).json(fournisseur);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};
// mettre à jour un fournisseur
const MisaJourFournisseur = async (req, res) => {
  try {
    const fournisseur = await Fournisseurs.findByPk(req.params.id);
    if (fournisseur) {
      await fournisseur.update(req.body);
      res.status(200).json(fournisseur);
    } else {
      res.status(404).json({ message: 'Fournisseur non trouvé' });
    }
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// supprimer un fournisseur
const SuprimerFournisseur = async (req, res) => {
  try {
    const fournisseur = await Fournisseurs.findByPk(req.params.id);
    if (fournisseur) {
      await fournisseur.destroy();
      res.status(204).send();
    } else {
      res.status(404).json({ message: 'Fournisseur non trouvé' });
    }
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export { getAllFournisseurs, AjoutNouvFournisseur , MisaJourFournisseur , SuprimerFournisseur };
