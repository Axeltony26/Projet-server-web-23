import {Adresse_livraison} from "../models/index.js";


// Fonction pour récupérer toutes les adresses de livraison

export const getAllAdressesLivraison = async (req, res) => {

  try {

    const adressesLivraison = await Adresse_livraison.findAll();

    res.json(adressesLivraison);

  } catch (error) {

    console.error(error);

    res.status(500).json({ message: "Une erreur est survenue" });

  }

};

// Fonction pour ajouter une nouvelle adresse de livraison

export const addAdresseLivraison = async (req, res) => {

  const { nom_destinataire, prenom_destinataire, pays, ville, rue, telephone, email } = req.body;

  try {

    const newAdresseLivraison = await Adresse_livraison.create({

      nom_destinataire,

      prenom_destinataire,

      pays,

      ville,

      rue,

      telephone,

      email,

    });

    res.status(201).json(newAdresseLivraison);

  } catch (error) {

    console.error(error);

    res.status(500).json({ message: "Une erreur est survenue" });

  }

};