import express from 'express';
import { getAllFournisseurs, AjoutNouvFournisseur, MisaJourFournisseur, SuprimerFournisseur } from "../controllers/Fournisseurs.js";

const router = express.Router();

// récupérer les fournisseurs
router.get('/', getAllFournisseurs);

// ajouter un fournisseur
router.post('/', AjoutNouvFournisseur);

// mettre à jour un fournisseur
router.put('/:id', MisaJourFournisseur);

// supprimer un fournisseur 
router.delete('/:id', SuprimerFournisseur);

export default router;
