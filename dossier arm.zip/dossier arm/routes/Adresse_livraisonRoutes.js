import express from "express";

import { getAllAdressesLivraison, addAdresseLivraison } from "../controllers/Adresse_livraison.js";

const router = express.Router();

// Route pour récupérer toutes les adresses de livraison

router.get("/", getAllAdressesLivraison);
 

// Route pour ajouter une nouvelle adresse de livraison

router.post("/", addAdresseLivraison);

export default router;