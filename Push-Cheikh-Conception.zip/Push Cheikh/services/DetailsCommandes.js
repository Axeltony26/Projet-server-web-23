import axios from 'axios'

const API_URL = 'http://localhost:5000/api'

export default {
  getDetailsCommande() {
    return axios.get(`${API_URL}/details-commande`)
  },
  saveDetailsCommande(details) {
    return axios.post(`${API_URL}/details-commande`, details)
  }
}