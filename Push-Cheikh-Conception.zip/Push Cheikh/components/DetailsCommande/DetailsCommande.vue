<template>
  <div>
    <h1>Ma commande</h1>
    <table>
      <thead>
        <tr>
          <th>Nom du produit</th>
          <th>Quantité</th>
          <th>Prix</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(detail, index) in detailsCommande" :key="index">
          <td>{{ detail.nom_produit_achete }}</td>
          <td>{{ detail.quantite }}</td>
          <td>{{ detail.prix }}</td>
          <td>
            <button @click="supprimerDetail(index)">Supprimer</button>
          </td>
        </tr>
      </tbody>
    </table><br>
    <form @submit.prevent="ajouterDetail">
      <label for="nom_produit_achete">Nom du produit :</label>
      <input type="text" id="nom_produit_achete" v-model="nouveauDetail.nom_produit_achete">
      <label for="quantite">Quantité :</label>
      <input type="number" id="quantite" v-model="nouveauDetail.quantite">
      <label for="prix">Prix :</label>
      <input type="number" id="prix" v-model="nouveauDetail.prix">
      <button>Ajouter</button>
    </form>
  </div>
</template>
<script>
export default {
  name: 'Commande',
  data() {
    return {
      detailsCommande: [
        { nom_produit_achete: 'Produit 1', quantite: 2, prix: 10 },
        { nom_produit_achete: 'Produit 2', quantite: 1, prix: 5 }
      ],
      nouveauDetail: {
        nom_produit_achete: '',
        quantite: 0,
        prix: 0
      }
    }
  },
  methods: {
    ajouterDetail() {
      this.detailsCommande.push({...this.nouveauDetail})
      this.nouveauDetail.nom_produit_achete = ''
      this.nouveauDetail.quantite = 0
      this.nouveauDetail.prix = 0
    },
    supprimerDetail(index) {
      this.detailsCommande.splice(index, 1)
    }
  }
}
</script>
<style scoped>
/* styles spécifiques au composant */
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  border: 1px solid black;
  padding: 8px;
  text-align: left;
}

th {
  background-color: #ccc;
}
</style>