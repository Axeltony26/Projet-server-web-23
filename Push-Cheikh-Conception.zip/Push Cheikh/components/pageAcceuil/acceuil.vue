<template>
    <div>
    <div >    
    <h3 > <b>Produits </b>|</h3>
    </div>
      <div class="row">
        <div class="col-md-4" v-for="(product, index) in products" :key="index">
          <div class="card mb-3">
            <img :src="product.image" class="card-img-top" :alt="product.name">
            <div class="card-body">
              <h5 class="card-title">{{ product.name }}</h5>
              <p class="card-text">{{ product.price }} $</p>
              <p class="card-text">{{ product.description }}</p>
              
             <!-- <button class="btn btn-primary" @click="addToCart(product)">Ajouter au panier</button>-->
              <button class="mt-3 but" style="margin-left: 80px; text-decoration: none; color: black;" @click="addToCart(product)">Ajouter au panier</button>

            </div>
          </div>
        </div>
      </div>
    </div>
    
    <h3 class="container-fluid mt-5"> <b> Nos Produits </b>| Livraison gratuite pour ses produits</h3>
    <hr class="mt-2">
    <div class="row">
        <div class="col-md-4" v-for="(product, index) in products" :key="index">
          <div class="card mb-3">
            <img :src="product.image" class="card-img-top" :alt="product.name">
            <div class="card-body">
              <h5 class="card-title">{{ product.name }}</h5>
              <p class="card-text">{{ product.price }} $</p>
              <p class="card-text">{{ product.description }}</p>
              
             <!-- <button class="btn btn-primary" @click="addToCart(product)">Ajouter au panier</button>-->
              <button class="mt-3 but" style="margin-left: 80px; text-decoration: none; color: black;" @click="addToCart(product)">Ajouter au panier</button>

            </div>
          </div>
        </div>
      </div>
      <h1 class="mt-5">Merci d'acheter des produits locaux!</h1>
      <footer class="container-fluid bg-dark text-white py-3">
    <div class="row">
      <div class="col-md-6">
        <div class="card border-0 bg-dark text-white">
          <div class="card-body">
            <h5 class="card-title">Your Shop</h5>
            <p class="card-text">Nous offrons une expérience de shopping agréable et conviviale, où nos clients peuvent trouver des produits de qualité supérieure à des prix compétitifs. Nous sommes passionnés par la nourriture saine et nous aimons partager nos connaissances avec nos clients pour les aider à faire des choix éclairés pour leur alimentation.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card border-0 bg-dark text-white">
          <div class="card-body">
            <h5 class="card-title">Coordonnées</h5>
            <p class="card-text">123 Rue des Dev<br>ON OTTAWA<br><br>Tél : +32 123 456 789<br>Email : lacite@worldtech22.com</p>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 text-center mt-3">
        <p class="mb-0">Copyright World Tech22</p>
      </div>
    </div>
  </footer>
  </template>
  
  <script>
  import { defineComponent } from 'vue'
  
  export default defineComponent({
    data() {
      return {
        products: [
          {
            id: 1,
            name: 'PANIERS DE LÉGUMES FRAIS- 100% LOCAL',
            description: 'Nos légumes sont choisis chaque semaine afin de vous offrir un choix diversifié dans vos paniers. ',
            price: 10,
            image: 'https://th.bing.com/th/id/R.6465fe393a75a520775b641cdb6a1de3?rik=sbsgCdS5O0UIGg&riu=http%3a%2f%2fwww.jxyfgroup.com%2fdata%2fupload%2fimage%2f20180622%2f1529634055716424.jpg&ehk=FuU1CuQqJNa%2fUyXBqbgNsZUT4zwcS4I%2fp44dG%2fQX8TE%3d&risl=&pid=ImgRaw&r=0',
          },
          {
            id: 2,
            name: 'PANIERS DE LÉGUMES FRAIS- 100% LOCAL',
            description: 'Nos légumes sont choisis chaque semaine afin de vous offrir un choix diversifié dans vos paniers. ',
            price: 20,
            image: 'https://th.bing.com/th/id/R.6465fe393a75a520775b641cdb6a1de3?rik=sbsgCdS5O0UIGg&riu=http%3a%2f%2fwww.jxyfgroup.com%2fdata%2fupload%2fimage%2f20180622%2f1529634055716424.jpg&ehk=FuU1CuQqJNa%2fUyXBqbgNsZUT4zwcS4I%2fp44dG%2fQX8TE%3d&risl=&pid=ImgRaw&r=0',
          },
          {
            id: 3,
            name: 'PANIERS DE LÉGUMES FRAIS- 100% LOCAL',
            description: 'Nos légumes sont choisis chaque semaine afin de vous offrir un choix diversifié dans vos paniers. ',
            price: 30,
            image: 'https://th.bing.com/th/id/R.6465fe393a75a520775b641cdb6a1de3?rik=sbsgCdS5O0UIGg&riu=http%3a%2f%2fwww.jxyfgroup.com%2fdata%2fupload%2fimage%2f20180622%2f1529634055716424.jpg&ehk=FuU1CuQqJNa%2fUyXBqbgNsZUT4zwcS4I%2fp44dG%2fQX8TE%3d&risl=&pid=ImgRaw&r=0',
          },
        ],
      }
    },
    methods: {
      addToCart(product) {
        this.$pinia.state.cart.addItem(product)
        alert('Le produit a été ajouté au panier !')
      },
    },
  })
  </script>
  <style>
  .but{
    border: 1px solid grey;
    box-shadow: 2px 2px 5px lightgrey;
    border-radius: 5px;
    box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); 
    background-color: grey;
  }
.but:hover {
  background-color: #0069d9;
}
</style>