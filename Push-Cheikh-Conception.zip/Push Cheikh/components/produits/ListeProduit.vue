<template>
  <div class="container">
    <h1 class="text-center mt-4 mb-4">Liste des produits</h1>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>Nom</th>
          <th>Description</th>
          <th>Prix</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(produit, index) in produits" :key="index">
          <td>{{ produit.nom }}</td>
          <td>{{ produit.description }}</td>
          <td>{{ produit.prix }}</td>
          <td>
            <button class="btn btn-primary" @click="edit(produit)">Modifier</button>
            <button class="btn btn-danger" style="margin-left: 20px; " @click="remove(produit)">Supprimer</button>
          </td>
        </tr>
      </tbody>
    </table>
    <form @submit.prevent="submit">
      <div class="row justify-content-center mt-4">
        <div class="col-12 col-sm-8">
          <div class="row mb-2">
            <label class="col-12 col-sm-6 form-label" for="nom">Nom du Produit</label>
            <div class="col-12 col-sm-6">
              <input class="form-control" :style="{ border: errorNom ? '1px solid red' : '' }" type="text" v-model="produit.nom"/>
              <div class="text-danger pb-2" v-if="errorNom">{{ errorNom }}</div>
            </div>
          </div>
          <div class="row mb-2">
            <label class="col-12 col-sm-6 form-label" for="description">Description du Produit</label>
            <div class="col-12 col-sm-6">
              <textarea class="form-control" :style="{ border: errorDescription ? '1px solid red' : '' }" v-model="produit.description"></textarea>
              <div class="text-danger pb-2" v-if="errorDescription">{{ errorDescription }}</div>
            </div>
          </div>
          <div class="row mb-2">
            <label class="col-12 col-sm-6 form-label" for="prix">Prix du Produit</label>
            <div class="col-12 col-sm-6">
              <input class="form-control" :style="{ border: errorPrix ? '1px solid red' : '' }" type="number" v-model="produit.prix"/>
              <div class="text-danger pb-2" v-if="errorPrix">{{ errorPrix }}</div>
            </div>
          </div>
          <div class="row justify-content-center mt-4">
            <div class="col-auto">
              <button class="btn btn-primary" type="submit">Ajouter</button>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      produits: [
        {
          nom: 'Bananas',
          description: 'Des fruits de qualites',
          prix: 10
        },
        {
          nom: '',
          description: '',
          prix: ''
        }
      ],
      produit: {
        nom: '',
        description: '',
        prix: ''
      },
      errorNom: '',
      errorDescription : '',
errorPrix: ''
};
},
methods: {
submit() {
// Vérification de la validité du nom
if (!this.produit.nom) {
this.errorNom = 'Le nom est obligatoire';
} else {
this.errorNom = '';
}
  // Vérification de la validité de la description
  if (!this.produit.description) {
    this.errorDescription = 'La description est obligatoire';
  } else {
    this.errorDescription = '';
  }

  // Vérification de la validité du prix
  if (!this.produit.prix || isNaN(this.produit.prix) || this.produit.prix < 0) {
    this.errorPrix = 'Le prix doit être un nombre positif';
  } else {
    this.errorPrix = '';
  }

  // Si toutes les données sont valides, on ajoute le produit
  if (!this.errorNom && !this.errorDescription && !this.errorPrix) {
    this.produits.push({
      nom: this.produit.nom,
      description: this.produit.description,
      prix: this.produit.prix
    });

    // On réinitialise les champs du formulaire
    this.produit.nom = '';
    this.produit.description = '';
    this.produit.prix = '';
  }
  
},
edit(produit) {
    this.produit = Object.assign({}, produit);
  },
  remove(produit) {
    const index = this.produits.indexOf(produit);
    if (index !== -1) {
      this.produits.splice(index, 1);
    }

}

}};
</script>

