import { defineStore } from 'pinia'

export const useCart = defineStore('cart', {
  state: () => ({
    items: [],
  }),
  getters: {
    total() {
      return this.items.reduce((acc, item) => acc + item.price, 0)
    },
  },
  actions: {
    addItem(product) {
      this.items.push(product)
    },
    removeItem(index) {
      this.items.splice(index, 1)
    },
  },
})
