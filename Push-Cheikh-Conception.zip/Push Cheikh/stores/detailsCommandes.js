import { defineStore } from 'pinia'
import commandeService from '@/services/commande.service'

export const useCommandeStore = defineStore('commande', {
  state: () => ({
    detailsCommande: []
  }),
  actions: {
    async loadDetailsCommande() {
      const response = await commandeService.getDetailsCommande()
      this.detailsCommande = response.data
    },
    async saveDetailsCommande(details) {
      await commandeService.saveDetailsCommande(details)
      await this.loadDetailsCommande()
    }
  }
})