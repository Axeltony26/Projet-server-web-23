import { defineStore } from 'pinia'
import produitService from '@/services/produitService'

export const useProduitStore = defineStore({
  id: 'produitStore',
  state: () => ({
    produits: []
  }),
  actions: {
    async fetchProduits() {
      this.produits = await produitService.getProduits()
    }
  }
})
