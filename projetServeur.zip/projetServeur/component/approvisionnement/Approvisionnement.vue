<template>
    <div class="container">
      <h2>Approvisionnement</h2>
      <form @submit.prevent="ajouterApprovisionnement" class="mb-3">
        <div class="row">
          <div class="col-md-4">
            <label for="nomFournisseur" class="form-label">Nom du fournisseur</label>
            <input id="nomFournisseur" v-model="nouvelApprovisionnement.nomFournisseur" class="form-control" required>
          </div>
          <div class="col-md-4">
            <label for="date" class="form-label">Date</label>
            <input id="date" type="date" v-model="nouvelApprovisionnement.date" class="form-control" required>
          </div>
          <div class="col-md-4">
            <label for="nomProduit" class="form-label">Nom du produit</label>
            <input id="nomProduit" v-model="nouvelApprovisionnement.nomProduit" class="form-control" required>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <label for="quantite" class="form-label">Quantité</label>
            <input id="quantite" type="number" v-model="nouvelApprovisionnement.quantite" class="form-control" required>
          </div>
          <div class="col-md-4 mt-4">
            <button type="submit" class="btn btn-primary">Ajouter</button>
          </div>
        </div>
      </form>
      <h2>Liste des approvisionnements</h2>
<table class="table">
  <thead>
    <tr>
      <th>Nom du fournisseur</th>
      <th>Date</th>
      <th>Nom du produit</th>
      <th>Quantité</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <tr v-for="(approvisionnement, index) in approvisionnements" :key="index">
      <td>{{ approvisionnement.nomFournisseur }}</td>
      <td>{{ approvisionnement.date }}</td>
      <td>{{ approvisionnement.nomProduit }}</td>
      <td>{{ approvisionnement.quantite }}</td>
      <td>
        <button class="btn btn-danger" @click="supprimerApprovisionnement(index)">Supprimer</button>
      </td>
    </tr>
  </tbody>
</table>

<div class="row">
  <div class="col-md-4 mt-4">
    <button class="btn btn-primary" @click="ajouterLigne">Ajouter une ligne</button>
  </div>
  <div class="col-md-4 mt-4">
    <button class="btn btn-danger" @click="supprimerLigne">Supprimer la dernière ligne</button>
  </div>
</div>
</div>
</template>
<script>
export default {
  data() {
    return {
      nouvelApprovisionnement: {
        nomFournisseur: '',
        date: '',
        nomProduit: '',
        quantite: '',
      },
      approvisionnements: [],
    };
  },
  methods: {
    ajouterApprovisionnement() {
      // Ajouter l'approvisionnement à la liste
      this.approvisionnements.push(this.nouvelApprovisionnement);

      // Vider les champs de saisie
this.nouvelApprovisionnement = {
nomFournisseur: "",
date: "",
nomProduit: "",
quantite: "",
};
},
supprimerApprovisionnement(index) {
  this.approvisionnements.splice(index, 1);
},

ajouterLigne() {
  let newLine = {
    nomFournisseur: '',
    date: '',
    nomProduit: '',
    quantite: '',
  };
  this.approvisionnements.push(newLine);
},

supprimerLigne(index) {
  this.approvisionnements.splice(index, 1);
},
}}
</script>

<style>
  th,
  td {
    text-align: center;
  }
</style>