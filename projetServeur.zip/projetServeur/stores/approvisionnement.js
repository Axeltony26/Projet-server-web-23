import { defineStore } from 'pinia';
import serviceApprovisionnement from '@/services/service-approvisionnement';

export const useApprovisionnementStore = defineStore({
  id: 'approvisionnement',
  state: () => ({
    approvisionnements: []
  }),
  actions: {
    async chargerApprovisionnements() {
      try {
        const response = await serviceApprovisionnement.getApprovisionnements();
        this.approvisionnements = response.data;
      } catch (error) {
        console.error(error);
      }
    },
    async ajouterApprovisionnement(approvisionnement) {
      try {
        const response = await serviceApprovisionnement.ajouterApprovisionnement(approvisionnement);
        this.approvisionnements.push(response.data);
      } catch (error) {
        console.error(error);
      }
    },
    async supprimerApprovisionnement(id) {
      try {
        await serviceApprovisionnement.supprimerApprovisionnement(id);
        this.approvisionnements = this.approvisionnements.filter(approvisionnement => approvisionnement.id !== id);
      } catch (error) {
        console.error(error);
      }
    }
  }
});
