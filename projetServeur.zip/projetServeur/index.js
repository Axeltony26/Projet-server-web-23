import { createRouter, createWebHistory } from 'vue-router'
// importez vos composants ici
import Login from '@/components/users/Login.vue'

import Register from '@/components/users/Register.vue'
//import ApprovisionnementListe from '@/components/approvisionnement/ApprovisionnementListe.vue'
//import ProduitListe from '@/components/produit/ProduitListe.vue'
//import ProduitListe from '@/components/produit/ProduitListe.vue'
//import ListeProduit from '@/components/produits/ListeProduit.vue'
import CategorieProduit from "@/components/categories/CategorieProduit.vue";
import Commandes from '@/components/commande/commande.vue'
//import Commandes from "@/components/Commandes.vue";
import { useCommandesStore } from "@/stores/Commandes";
import ListeProduits from '@/components/produits/ListeProduit.vue'
import Home from '@/components/pageAcceuil/acceuil.vue'
import AddToCart from '@/components/panier/AddToCart.vue'
//import Fournisseurs from '@/components/fournisseur/fournisseur.vue'
import Fournisseur from '@/components/fournisseur/fournisseur.vue'
import AdresseLivraison from "@/components/AdresseLivraison/adresseLivraison.vue";
import DetailCommande from '@/components/DetailsCommande/DetailsCommande.vue'
import Approvisionnement from '@/components/approvisionnement/Approvisionnement.vue';
const routes = [
  {
    path: '/home',
    name: 'home',
    component: Home,
  },
  {
    path: '/add-to-cart/:productId',
    name: 'AddToCart',
    component: AddToCart,
    props: true,
  },
    {
      path: '/login',
      name: 'Login',
      component: Login
    },
    {
      path: "/ajouter-adresse-livraison",
      name: "AjouterAdresseLivraison",
      component: AdresseLivraison,
    },
    {
      path: '/approvisionnement',
      name: 'Approvisionnement',
      component: Approvisionnement
    },
    {
      path: '/detail-commande/:id',
      name: 'detail-commande',
      component: DetailCommande
    },
    {
      path: '/produits',
      name: 'produits',
      component: ListeProduits
    },
    {
      path: '/fournisseurs',
      name: 'Fournisseur',
      component: Fournisseur
    },
    {
      path: '/register',
      name: 'Register',
      component: Register
    },
 
  {
    path: "/categorie-produit",
    name: "CategorieProduit",
    component: CategorieProduit,
  },
  {
    path: "/commandes",
    name: "commandes",
    component: Commandes,
    beforeEnter: async (to, from, next) => {
      const store = useCommandesStore();
      if (store.commandes.length === 0) {
        await store.fetchCommandes();
      }
      next();
    },
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router




