<template>
  <div id="app">
    <header>
       <!-- <h1 class="bg-dark text-center text-white"><marquee> Bienvenue sur notre site de vente en ligne </marquee></h1>-->
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
         <!-- <router-link class="navbar-brand" to="/">Projet Groupe</router-link>-->
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <router-link class="nav-link" to="/home">Accueil</router-link>
              </li>
           <!--   <li class="nav-item">
                <router-link class="nav-link" to="/approvisionnements">Approvisionnements</router-link>
              </li>-->
              <li class="nav-item">
              <router-link class="nav-link" to="/categorie-produit">Categorie</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/produits">Produit</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/commandes">Commande</router-link>
            </li>
            <li class="nav-item">
      
              <router-link class="nav-link" to="/fournisseurs">Fournisseur</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/ajouter-adresse-livraison">AdresseLivraison</router-link>
            </li>
              <li class="nav-item">
              
              <router-link class="nav-link" to="/approvisionnement">Approvisionnements</router-link>
            </li>
         <!--   <li class="nav-item">
              <router-link class="nav-link" to="/approvisionnements/ajouter">Ajouterunnouvelapprovisionnement</router-link>
            </li>-->
              <li class="nav-item">
                <router-link class="nav-link" to="/detail-commande/:id">DetailsCommande</router-link>
              </li>
            </ul>
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <router-link  class="nav-link" to="/login"> Connexion</router-link>
              </li>
              <li class="nav-item">
                <router-link class="nav-link" to="/register">Inscription</router-link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <main class="container mt-4">
      <router-view></router-view>
    </main>
  </div>
  
</template>

<style>
.nav-item:hover {
  background-color: #007bff;
}

.nav-item:hover .nav-link {
  color: #fff;
}
</style>