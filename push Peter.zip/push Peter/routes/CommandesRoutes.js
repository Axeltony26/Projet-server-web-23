import { Router } from "express";
import Comm from "../controllers/Commandes.js";
const router = Router();

router
    .get('/',Comm.getCommandes)
    .post('/', Comm.createCommande)
    .get('/:id', Comm.getCommande)
    .put('/:id', Comm.updateCommande)
    .delete('/:id', Comm.deleteCommande)

   
    export default router;
