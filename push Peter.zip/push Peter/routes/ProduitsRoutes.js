import { Router } from "express";
import ProduitC from "../controllers/Produits.js";
const router = Router()

router
    .get('/', ProduitC.getProduits)
    .post('/', ProduitC.createProduit)
    .get('/:id', ProduitC.getProduit)
    .put('/:id', ProduitC.updateProduit)
    .delete('/:id',ProduitC.deleteProduit)
   
    export default router

