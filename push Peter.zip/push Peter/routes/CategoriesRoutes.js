import { Router } from "express";
import CategoriesP from "../controllers/Categories_produits.js";
const router = Router()

router
    .get('/', CategoriesP.getCategories)
    .post('/', CategoriesP.createCategorie) 
    .get('/:id', CategoriesP.getCategorie) 
    .put('/:id', CategoriesP.updateCategorie) 
    .delete('/:id', CategoriesP.deleteCategorie) 

   
    export default router
