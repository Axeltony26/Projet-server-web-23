//Importer la base de donnee pour creer les modeles
import database from "../connexion.js";
import { DataTypes } from 'sequelize'

//Modele de la table student
const Commandes = database.define('Commandes', {
    montant: { type: DataTypes.STRING, allowNull: false },
    date: { type: DataTypes.DATEONLY },
    statut:{ type: DataTypes.STRING, allowNull: false },
},
    { //Ajouter cet objet pour ne pas avoir les colonnes createdAt and updatedAt automatiquement
        timestamps: false
    })


export default Commandes


