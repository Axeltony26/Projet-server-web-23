import { Router } from "express";
import { getAllUsers,addUsers,updateUsers,getUsersById,deleteUsers,createRoleUsers,getUsersRoles,userLogin } from "../controllers/Users.js";
const router = Router()

router
.get('/', getAllUsers)
    .post('/', addUsers)
    .get('/:id', getUsersById)
    .put('/:id', updateUsers)
    .get('/:id/notes', getUsersRoles)
    .post('/:id/notes', createRoleUsers)
    .delete('/:id', deleteUsers)
    .post('/login', userLogin)

    export default router
