import { Router } from "express";

import { getAllRoles,getRoleById,deleteRole,updateRole } from "../controllers/Roles.js";
const router = Router()

router 
.get('/', getAllRoles)
    .get('/:id', getRoleById)
    .put('/:id', updateRole)
    .delete('/:id', deleteRole)

    export default router