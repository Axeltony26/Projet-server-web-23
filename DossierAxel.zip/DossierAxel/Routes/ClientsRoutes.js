import { Router } from "express";
import { getAllClients,addClients,updateClients,getClientsById,deleteClients } from "../controllers/Clients.js";
const router = Router()

router
.get('/', getAllClients)
    .post('/', addClients)
    .get('/:id', getClientsById)
    .put('/:id', updateClients)
    .delete('/:id', deleteClients)

    export default router
