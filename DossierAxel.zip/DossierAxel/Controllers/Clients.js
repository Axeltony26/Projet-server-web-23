import { Clients } from "../models/index.js";
import { validationResult } from "express-validator"
// Ajouter un client
export const addClients = async (req, res) => {

    const { nom, prenom, naissance,telephone,email,mot_de_passe } = req.body
    const newClients = { nom, prenom, naissance,telephone,email,mot_de_passe }
//Erreurs de validation

const errors = validationResult(req)
if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() })   
}
    try {
        const result = await Clients.create(newClients)
        res.status(201).json({ data: result, message: 'Client cree avec succes' })
    } catch (error) {
        res.status(400).json({ error: true, message: error.message })
    }
}
//Mettre a jour un client
export const updateClients = async (req, res) => {
    const { id } = req.params

    if (!id) return res.status(404).json({ message: 'id est obligatoire' })

    const { nom, prenom, naissance,telephone,email,mot_de_passe } = req.body
    const updatedClients = { nom, prenom, naissance,telephone,email,mot_de_passe }
    try {
        const result = await Clients.update(updatedClients, { where: { id } })
        res.status(200).json({ message: 'Client updated' })

    } catch (error) {
        res.status(400).json({ error: true, message: error.message })
    }
}
//Obtenir les infos d'un client
export const getClientsById = async (req, res) => {
    const { id } = req.params
    if (!id) return res.status(404).json({ message: 'id est obligatoire' })

    try {
        const result = await Clients.findByPk(id)
        res.status(200).json({ data: result })

    } catch (error) {
        res.status(400).json({ error: true, message: error.message })
    }
}
//la liste de tous les clients
export const getAllClients = async (req, res) => {
    try {
        const result = await Clients.findAll()
        res.status(200).json({ data: result, message: "Tous les Clients recus" })

    } catch (error) {
        res.status(404).json({ error: true, message: error.message })
    }
}
//Supprimer un client
export const deleteClients = async (req, res) => {
    const clientsId = req.params.id
    if (!clientsId) return res.status(404).json({ error: true, message: error.message })

    try {
        const result = await Clients.destroy({ where: { id: clientsId } })
        res.status(200).json({ data: result, message: 'Client supprime' })
    } catch (error) {
        res.status(400).json({ message: error.message })
    }
}