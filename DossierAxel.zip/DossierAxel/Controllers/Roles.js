import { Roles } from "../models/index.js"

//Chercher la liste de tous les roles
export const getAllRoles = async (req, res) => {

    try {
        const result = await Roles.findAll()
        res.status(200).json({ data: result })
    } catch (error) {
        res.status(404).json({ message: error.message })
    }
}


//Retourner un role
export const getRoleById = async (req, res) => {
    const { id } = req.params
    if (!id) return res.status(404).json({ message: 'id est obligatoire' })
    try {
        //Retourner l'utilisateur auquel le role appartient
        const result = await Roles.findByPk(id, { include:"Users"})  
        res.status(200).json({ data: result })
    } catch (error) {
        res.status(404).json({ message: error.message })
    }
}
// Supprimer un role
export const deleteRole = async (req, res) => {
    const { id } = req.params
    if (!id) res.status(404).json({ error: true, message: "L'id est requis" })
    try {
        const result = await Roles.destroy({ where: { id } })
        res.status(200).json({ message: `Le role ${id} a ete supprimee avec succes` })
    } catch (error) {
        res.status(404).json({ error: true, message: error.message })
    }
}
// Mettre a jour un role
export const updateRole = async (req, res) => {
    let { id } = req.params
    const { nom } = req.body
    const updatedRole = { nom }

    if (!id) res.status(400).json({ message: 'id du role est requis' })
    try {
        const result = await Roles.update(updatedRole, { where: { id } })
        res.status(200).json(result)
    } catch (error) {
        res.status(404).json({ message: error.message })
    }

}