<template>
    <div>
        <table class="table mt-2">
        <thead>
          <tr>
            <th><strong>Nom</strong></th>
            <th><strong>Prénom</strong> </th>
            <th><strong>Pays</strong></th>
            <th><strong>Ville</strong></th>
            <th><strong>Rue</strong></th>
            <th><strong>Téléphone</strong></th>
            <th><strong>Email</strong></th>
            <th><strong>Actions</strong></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(fournisseur, index) in fournisseurs" :key="index">
            <td>{{ fournisseur.nom }}</td>
            <td>{{ fournisseur.prenom }}</td>
            <td>{{ fournisseur.pays }}</td>
            <td>{{ fournisseur.ville }}</td>
            <td>{{ fournisseur.rue }}</td>
            <td>{{ fournisseur.telephone }}</td>
            <td>{{ fournisseur.email }}</td>
            <td>
              <button type="button" class="btn btn-danger" @click="supprimerFournisseur(index)">Supprimer</button>
              <button type="button" class="btn btn-secondary" @click="editerFournisseur(index)">Modifier</button>
            </td>
            </tr>
        </tbody>
      </table>
      <form>
        <div class="mb-3">
          <label for="nom" class="form-label">Nom :</label>
          <input type="text" class="form-control form-control-sm" id="nom" v-model="nouveauFournisseur.nom" required>
        </div>
        <div class="mb-3">
          <label for="prenom" class="form-label">Prénom :</label>
          <input type="text" class="form-control form-control-sm" id="prenom" v-model="nouveauFournisseur.prenom" required>
        </div>
        <div class="mb-3">
          <label for="pays" class="form-label">Pays :</label>
          <input type="text" class="form-control form-control-sm" id="pays" v-model="nouveauFournisseur.pays" required>
        </div>
        <div class="mb-3">
          <label for="ville" class="form-label">Ville :</label>
          <input type="text" class="form-control form-control-sm" id="ville" v-model="nouveauFournisseur.ville" required>
        </div>
        <div class="mb-3">
          <label for="rue" class="form-label">Rue :</label>
          <input type="text" class="form-control form-control-sm" id="rue" v-model="nouveauFournisseur.rue" required>
        </div>
        <div class="mb-3">
          <label for="telephone" class="form-label">Téléphone :</label>
          <input type="text" class="form-control form-control-sm" id="telephone" v-model="nouveauFournisseur.telephone" required>
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">Email :</label>
          <input type="email" class="form-control form-control-sm" id="email" v-model="nouveauFournisseur.email" required>
        </div>
        <div>
          <button type="button" class="btn btn-primary" @click="ajouterFournisseur">Ajouter</button>
        </div>
      </form>
      
    </div>
  </template>
  
  
  <script>
  export default {
    data() {
      return {
        nouveauFournisseur: {
          nom: '',
          prenom: '',
          pays: '',
          ville: '',
          rue: '',
          telephone: '',
          email: ''
        },
        fournisseurs: []
      }
    },
    methods: {
      ajouterFournisseur() {
        this.fournisseurs.push(this.nouveauFournisseur);
        this.nouveauFournisseur = {
          nom: '',
          prenom: '',
          pays: '',
          ville: '',
          rue: '',
          telephone: '',
          email: ''
        }
      },
      supprimerFournisseur(index) {
        this.fournisseurs.splice(index, 1);
      },
      editerFournisseur(index) {
        this.nouveauFournisseur = this.fournisseurs[index];
        this.fournisseurs.splice(index, 1);
      }
    }
  }
  </script>