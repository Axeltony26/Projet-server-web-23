<template>
  <div class="row">
    <div class="col-md-6">
      <h2> Fruits </h2>
      <table class="table table-bordered shadow">
        <thead>
          <tr>
            <th><b>Nom</b></th>
            <th><b>Pays d'origine</b></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(fruit, index) in fruits" :key="index">
            <td>{{ fruit.name }}</td>
            <td>{{ fruit.country }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="col-md-6">
      <h2> Légumes </h2>
      <table class="table table-bordered shadow">
        <thead>
          <tr>
            <th><b>Nom</b></th>
            <th><b>Pays d'origine</b></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(legume, index) in legumes" :key="index">
            <td>{{ legume.name }}</td>
            <td>{{ legume.country }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      fruits: [
        { name: "Pomme", country: "Senegal" },
        { name: "Banane", country: "Maroc" },
        { name: "Orange", country: "France" },
        { name: "Raisin", country: "Canada" }
      ],
      legumes: [
        { name: "Carotte", country: "Cote D'ivoire" },
        { name: "Tomate", country: "Mali" },
        { name: "Concombre", country: "Cameroun" },
        { name: "Poivron", country: "Mexique" }
      ]
    };
  }
};
</script>

<style>
</style>