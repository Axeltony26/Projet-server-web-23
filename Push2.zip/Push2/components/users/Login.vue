<template>
    <div class="d-flex justify-content-center align-items-center min-vh-100">
      <div class="card p-4 shadow" style="width: 600px;">
        <h1 class="text-center mb-4">Login</h1>
        <form @submit.prevent="loginUser">
          <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" id="email" v-model="email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Password:</label>
            <input type="password" id="password" v-model="password" class="form-control" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
        <p v-if="error" class="text-danger mt-3">{{ error }}</p>
      </div>
    </div>
  </template>
  
  
  
  <script>
  export default {
    data() {
      return {
        email: '',
        password: '',
        error: ''
      }
    },
    methods: {
      async loginUser() {
        try {
          await this.$store.dispatch('users/loginUser', { email: this.email, password: this.password })
          this.$router.push('/')
          alert('Vous êtes connecté avec succès !');
        } catch (error) {
          this.error = error.response.data.message
        }
      }
    },
  

  }
  </script>
  