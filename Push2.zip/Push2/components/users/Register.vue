<template>
  <div class="d-flex justify-content-center align-items-center min-vh-100">
    <div class="card p-4" style="width: 400px; border: 1px solid rgba(0, 0, 0, 0.2); box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);">
      <h1 class="text-center mb-4">Register</h1>
      <form @submit.prevent="registerUser">
        <div class="mb-3">
          <label for="name" class="form-label">Name:</label>
          <input type="text" id="name" v-model="name" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">Email:</label>
          <input type="email" id="email" v-model="email" class="form-control" required>
        </div>       
        <div class="mb-3">
          <label for="dob" class="form-label">Date of Birth:</label>
          <input type="date" id="dob" v-model="dob" class="form-control" required>
        </div>    
        <div class="mb-3">
          <label for="photo" class="form-label">Photo:</label>
          <input type="file" id="photo" class="form-control" accept="image/*" @change="onFileChange" required>
        </div>
        <div class="mb-3">
          <label for="phone" class="form-label">Phone:</label>
          <input type="tel" id="phone" v-model="phone" class="form-control" required>
        </div>
          <div class="mb-3">
          <label for="password" class="form-label">Password:</label>
          <input type="password" id="password" v-model="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Register</button>
      </form>
      <p v-if="error" class="text-danger mt-3">{{ error }}</p>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      name: '',
      email: '',
      password: '',
      dob: '',
      phone: '',
      photo: '',
      error: ''
    }
  },
  methods: {
    async registerUser() {
      try {
        const formData = new FormData()
        formData.append('name', this.name)
        formData.append('email', this.email)
        formData.append('password', this.password)
        formData.append('dob', this.dob)
        formData.append('phone', this.phone)
        formData.append('photo', this.photo)
        await this.$store.dispatch('users/registerUser', formData)
        this.$router.push('/')
      } catch (error) {
        this.error = error.response.data.message
      }
    },
  onFileChange(event) { // méthode pour capturer la photo sélectionnée
    this.photo = event.target.files[0]
  }
}
}
</script>