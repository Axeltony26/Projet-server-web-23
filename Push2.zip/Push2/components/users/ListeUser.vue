<template>
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h1>Liste des utilisateurs</h1>
          <ul>
            <li v-for="(user, index) in users" :key="index">{{ user.name }} - {{ user.email }}</li>
          </ul>
        </div>
        <div class="col-md-6">
          <h1>Ajouter un nouvel utilisateur</h1>
          <form @submit.prevent="addUser">
            <div class="form-group">
              <label for="name">Nom</label>
              <input type="text" class="form-control" id="name" v-model="name" required>
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" class="form-control" id="email" v-model="email" required>
            </div>
            <div class="form-group">
              <label for="password">Mot de passe</label>
              <input type="password" class="form-control" id="password" v-model="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Ajouter</button>
          </form>
          <p v-if="error" class="text-danger mt-3">{{ error }}</p>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        name: '',
        email: '',
        password: '',
        error: '',
        users: []
      }
    },
    created() {
      this.fetchUsers()
    },
    methods: {
      async fetchUsers() {
        try {
          const response = await this.$axios.get('/api/users')
          this.users = response.data
        } catch (error) {
          console.error(error)
        }
      },
      async addUser() {
        try {
          await this.$axios.post('/api/users', { name: this.name, email: this.email, password: this.password })
          this.name = ''
          this.email = ''
          this.password = ''
          this.error = ''
          this.fetchUsers()
        } catch (error) {
          this.error = error.response.data.message
        }
      }
    }
  }
  </script>
  