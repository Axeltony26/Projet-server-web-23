import axios from 'axios'

const API_URL = 'http://localhost:3000/api/users/'

class UserService {
  async register(newUser) {
    const response = await axios.post(API_URL + 'register', newUser)
    return response.data
  }

  async login(credentials) {
    const response = await axios.post(API_URL + 'login', credentials)
    return response.data
  }
}

export default new UserService()
