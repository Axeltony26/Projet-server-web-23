// fournisseur.service.js

import axios from 'axios';

class FournisseurService {
  constructor() {
    this.apiUrl = 'http://localhost:3000/api/fournisseurs';
  }

  async getAllFournisseurs() {
    const response = await axios.get(this.apiUrl);
    return response.data;
  }

  async addFournisseur(fournisseur) {
    const response = await axios.post(this.apiUrl, fournisseur);
    return response.data;
  }

  async updateFournisseur(fournisseur) {
    const response = await axios.put(`${this.apiUrl}/${fournisseur.id}`, fournisseur);
    return response.data;
  }

  async deleteFournisseur(id) {
    const response = await axios.delete(`${this.apiUrl}/${id}`);
    return response.data;
  }
}

export default new FournisseurService();
