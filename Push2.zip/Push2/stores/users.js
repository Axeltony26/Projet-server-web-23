import userService from '@/services/users.js'

const state = {
  user: null
}

const getters = {
  currentUser: state => state.user
}

const mutations = {
  SET_USER(state, user) {
    state.user = user
  }
}

const actions = {
  async register({ commit }, newUser) {
    try {
      const user = await userService.register(newUser)
      commit('SET_USER', user)
      return Promise.resolve(user)
    } catch (error) {
      return Promise.reject(error)
    }
  },

  async login({ commit }, credentials) {
    try {
      const user = await userService.login(credentials)
      commit('SET_USER', user)
      return Promise.resolve(user)
    } catch (error) {
      return Promise.reject(error)
    }
  },

  logout({ commit }) {
    commit('SET_USER', null)
  }
}

export default {
  state,
  getters,
  mutations,
  actions
}
