import { defineStore } from 'pinia';
import FournisseurService from '@/services/Fournisseurs';

export const useFournisseurStore = defineStore('fournisseur', {
  state: () => ({
    fournisseurs: [],
    fournisseurEnEdition: null,
    erreursValidation: null,
  }),

  actions: {
    async recupererFournisseurs() {
      const fournisseurs = await FournisseurService.recupererFournisseurs();
      this.fournisseurs = fournisseurs;
    },

    async ajouterFournisseur(fournisseur) {
      const resultat = await FournisseurService.ajouterFournisseur(fournisseur);
      if (resultat.succes) {
        this.fournisseurs.push(resultat.fournisseur);
      } else {
        this.erreursValidation = resultat.erreurs;
      }
    },

    async modifierFournisseur(fournisseur) {
      const resultat = await FournisseurService.modifierFournisseur(fournisseur);
      if (resultat.succes) {
        const index = this.fournisseurs.findIndex(f => f.id === fournisseur.id);
        if (index !== -1) {
          this.fournisseurs.splice(index, 1, resultat.fournisseur);
        }
      } else {
        this.erreursValidation = resultat.erreurs;
      }
    },

    async supprimerFournisseur(fournisseur) {
      const resultat = await FournisseurService.supprimerFournisseur(fournisseur.id);
      if (resultat.succes) {
        const index = this.fournisseurs.findIndex(f => f.id === fournisseur.id);
        if (index !== -1) {
          this.fournisseurs.splice(index, 1);
        }
      }
    },

    mettreAJourFournisseurEnEdition(fournisseur) {
      this.fournisseurEnEdition = fournisseur;
    },

    mettreAJourErreursValidation(erreurs) {
      this.erreursValidation = erreurs;
    },
  },
});

export default useFournisseurStore;
