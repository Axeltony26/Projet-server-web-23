import { defineStore } from "pinia";
import CategoriesService from "@/services/Categories";

export const useCategoriesStore = defineStore({
  id: "categories",
  state: () => ({
    categories: [],
  }),
  actions: {
    async fetchCategories() {
      const response = await CategoriesService.getAll();
      this.categories = response.data;
    },
    async createCategory(category) {
      await CategoriesService.create(category);
      await this.fetchCategories();
    },
    async updateCategory(category) {
      await CategoriesService.update(category.id, category);
      await this.fetchCategories();
    },
    async deleteCategory(id) {
      await CategoriesService.delete(id);
      await this.fetchCategories();
    },
  },
});
